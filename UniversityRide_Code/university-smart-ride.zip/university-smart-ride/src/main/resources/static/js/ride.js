
document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("searchRideForm");
    const results = document.getElementById("rideResults");

    if (!form || !results) {
        return;
    }

    form.addEventListener("submit", async function (event) {
        event.preventDefault();

        const source = document.getElementById("pickup").value.trim();
        const destination = document.getElementById("destination").value.trim();
        const date = document.getElementById("travel-date").value;

        results.textContent = "Searching for rides...";

        try {
            const params = new URLSearchParams({
                source: source,
                destination: destination
            });

            if (date) {
                params.append("date", date);
            }

            const response = await fetch(
                `/api/rides/search?${params.toString()}`
            );

            if (!response.ok) {
                throw new Error("Could not fetch rides.");
            }

            const rides = await response.json();
            results.replaceChildren();

            if (rides.length === 0) {
                results.textContent =
                    "No matching rides found. Please try another route.";
                return;
            }

            rides.forEach(function (ride) {
                const card = document.createElement("div");
                card.className = "ride-result-card";

                const heading = document.createElement("h3");
                heading.textContent =
                    `${ride.source} → ${ride.destination}`;

                const details = document.createElement("p");
                details.textContent =
                    `Date: ${ride.rideDate} | Time: ${ride.rideTime}`;

                const seats = document.createElement("p");
                seats.textContent =
                    `Available seats: ${ride.availableSeats}`;


					const vehicle = document.createElement("p");
					vehicle.textContent =
					    `Vehicle: ${ride.vehicleDetails || "Not specified"}`;

					const contribution = document.createElement("p");
					contribution.textContent =
					    `Contribution: ₹${ride.contribution ?? 0}`;


					card.append(heading, vehicle, details, seats, contribution);
					results.appendChild(card);

            });
        } catch (error) {
            results.textContent =
                "Unable to load rides. Check that Spring Boot and MySQL are running.";
            console.error(error);
        }
    });
});

document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("offerRideForm");
    const message = document.getElementById("offerRideMessage");

    if (!form || !message) {
        return;
    }

    form.addEventListener("submit", async function (event) {
        event.preventDefault();

        const rideData = {
            driverId: Number(document.getElementById("driverId").value),
            source: document.getElementById("rideSource").value.trim(),
            destination: document.getElementById("rideDestination").value.trim(),
            rideDate: document.getElementById("rideDate").value,
            rideTime: document.getElementById("rideTime").value,
            availableSeats: Number(document.getElementById("availableSeats").value),
            contribution: Number(document.getElementById("contribution").value),
            vehicleDetails: document.getElementById("vehicleDetails").value.trim()
        };

        message.textContent = "Publishing your ride...";

        try {
            const response = await fetch("/api/rides", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(rideData)
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.detail || result.message || "Could not publish ride.");
            }

            message.textContent = "Ride published successfully!";
            form.reset();

        } catch (error) {
            message.textContent = error.message ||
                "Unable to publish ride. Please try again.";
        }
    });
});


document.addEventListener("DOMContentLoaded", function () {
    const busCard = document.querySelector(
        '#buses a[href="#buses"]'
    );

    const busSection = document.getElementById("university-bus-list");
    const hero = document.getElementById("home");
    const findRide = document.getElementById("find-ride");
    const services = document.getElementById("services");
    const footer = document.querySelector(".footer");
    const backButton = document.getElementById("backToHome");

    if (!busCard || !busSection) {
        console.error("Bus card or bus section was not found.");
        return;
    }

    busCard.addEventListener("click", function (event) {
        event.preventDefault();

        if (hero) hero.hidden = true;
        if (findRide) findRide.hidden = true;
        if (services) services.hidden = true;
        if (footer) footer.hidden = true;

        busSection.hidden = false;

        window.scrollTo({ top: 0, behavior: "smooth" });
    });

    if (backButton) {
        backButton.addEventListener("click", function () {
            busSection.hidden = true;

            if (hero) hero.hidden = false;
            if (findRide) findRide.hidden = false;
            if (services) services.hidden = false;
            if (footer) footer.hidden = false;

            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }
});


document.addEventListener("DOMContentLoaded", function () {
    const busCard = document.querySelector(
        '#buses a[href="#buses"]'
    );

    const busSection = document.getElementById("university-bus-list");
    const hero = document.getElementById("home");
    const findRide = document.getElementById("find-ride");
    const services = document.getElementById("services");
    const footer = document.querySelector(".footer");
    const backButton = document.getElementById("backToHome");

    if (!busCard || !busSection) {
        console.error("Bus card or bus section was not found.");
        return;
    }

    busCard.addEventListener("click", function (event) {
        event.preventDefault();

        if (hero) hero.hidden = true;
        if (findRide) findRide.hidden = true;
        if (services) services.hidden = true;
        if (footer) footer.hidden = true;

        busSection.hidden = false;

        window.scrollTo({ top: 0, behavior: "smooth" });
    });

    if (backButton) {
        backButton.addEventListener("click", function () {
            busSection.hidden = true;

            if (hero) hero.hidden = false;
            if (findRide) findRide.hidden = false;
            if (services) services.hidden = false;
            if (footer) footer.hidden = false;

            window.scrollTo({ top: 0, behavior: "smooth" });
        });
    }
});


document.addEventListener("DOMContentLoaded", async function () {
    const busList = document.getElementById("busRoutesList");

    if (!busList) return;

    busList.textContent = "Loading bus routes...";

    try {
        const response = await fetch("/api/bus-routes");

        if (!response.ok) {
            throw new Error("Could not load bus routes.");
        }

        const routes = await response.json();

        busList.replaceChildren();

        if (!Array.isArray(routes) || routes.length === 0) {
            busList.textContent = "No bus routes are available.";
            return;
        }

        routes.forEach(function (route) {
            const card = document.createElement("article");
            card.className = "service-card";

            const title = document.createElement("h3");
            title.textContent =
                `${route.routeNumber} - ${route.routeName}`;

            const journey = document.createElement("p");
            journey.textContent =
                `${route.startingPoint} → ${route.destination}`;

            const timing = document.createElement("p");
            timing.textContent =
                `Departure: ${route.busTime} | Arrival: ${route.arrivalTime}`;

            const stopsButton = document.createElement("button");
            stopsButton.type = "button";
            stopsButton.className = "primary-btn";
            stopsButton.textContent = "View Stops";

            const stopsList = document.createElement("div");
            stopsList.hidden = true;

            stopsButton.addEventListener("click", async function () {
                if (!stopsList.hidden) {
                    stopsList.hidden = true;
                    stopsButton.textContent = "View Stops";
                    return;
                }

                stopsList.hidden = false;
                stopsList.textContent = "Loading stops...";

                try {
                    const stopResponse = await fetch(
                        `/api/bus-stops/route/${route.id}`
                    );

                    if (!stopResponse.ok) {
                        throw new Error("Could not load stops.");
                    }

                    const stops = await stopResponse.json();
                    stopsList.replaceChildren();

                    if (!Array.isArray(stops) || stops.length === 0) {
                        stopsList.textContent = "No stops listed.";
                        return;
                    }

                    stops.forEach(function (stop) {
                        const stopItem = document.createElement("p");
                        stopItem.textContent =
                            `${stop.stopName} - ${stop.stopTime}`;
                        stopsList.appendChild(stopItem);
                    });

                    stopsButton.textContent = "Hide Stops";
                } catch (error) {
                    stopsList.textContent =
                        "Unable to load stops. Please try again.";
                    console.error(error);
                }
            });

            card.append(title, journey, timing, stopsButton, stopsList);
            busList.appendChild(card);
        });
    } catch (error) {
        busList.textContent =
            "Unable to load bus routes. Check the API and try again.";
        console.error("Bus routes error:", error);
    }
});

