
package com.university.smartride.repository;

import com.university.smartride.entity.BusStop;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface BusStopRepository extends JpaRepository<BusStop, Integer> {

    List<BusStop> findByRouteIdOrderByStopOrderAsc(Integer routeId);

}
