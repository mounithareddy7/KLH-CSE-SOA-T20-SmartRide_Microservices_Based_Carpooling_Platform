
package com.university.smartride.controller;

import com.university.smartride.entity.Ride;
import com.university.smartride.entity.User;
import com.university.smartride.repository.RideRepository;
import com.university.smartride.repository.UserRepository;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalTime;
import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/rides")
public class RideController {

    private final RideRepository rideRepository;
    private final UserRepository userRepository;

    public RideController(
            RideRepository rideRepository,
            UserRepository userRepository) {
        this.rideRepository = rideRepository;
        this.userRepository = userRepository;
    }

    @GetMapping
    public List<Ride> getAllRides() {
        return rideRepository.findAll();
    }

    @GetMapping("/search")
    public List<Ride> searchRides(
            @RequestParam String source,
            @RequestParam String destination) {

        return rideRepository
                .findBySourceContainingIgnoreCaseAndDestinationContainingIgnoreCase(
                        source, destination);
    }

    @GetMapping("/date")
    public List<Ride> getRidesByDate(
            @RequestParam LocalDate date) {

        return rideRepository.findByRideDateAndStatus(
                date, Ride.RideStatus.AVAILABLE);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Ride offerRide(@RequestBody RideRequest request) {

        if (request.getDriverId() == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, "Driver ID is required");
        }

        User driver = userRepository.findById(request.getDriverId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "User not found. Register the driver first."));

        if (request.getSource() == null
                || request.getSource().isBlank()
                || request.getDestination() == null
                || request.getDestination().isBlank()
                || request.getRideDate() == null
                || request.getRideTime() == null
                || request.getAvailableSeats() == null
                || request.getAvailableSeats() < 1) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Please provide valid ride details");
        }

        if (request.getRideDate().isBefore(LocalDate.now())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Travel date cannot be in the past");
        }

        Ride ride = new Ride();
        ride.setDriver(driver);
        ride.setSource(request.getSource().trim());
        ride.setDestination(request.getDestination().trim());
        ride.setRideDate(request.getRideDate());
        ride.setRideTime(request.getRideTime());
        ride.setAvailableSeats(request.getAvailableSeats());
        ride.setContribution(
                request.getContribution() == null
                        ? BigDecimal.ZERO : request.getContribution());
        ride.setVehicleDetails(request.getVehicleDetails());
        ride.setStatus(Ride.RideStatus.AVAILABLE);

        return rideRepository.save(ride);
    }

    public static class RideRequest {
        private Integer driverId;
        private String source;
        private String destination;
        private LocalDate rideDate;
        private LocalTime rideTime;
        private Integer availableSeats;
        private BigDecimal contribution;
        private String vehicleDetails;

        public Integer getDriverId() { return driverId; }
        public void setDriverId(Integer driverId) {
            this.driverId = driverId;
        }

        public String getSource() { return source; }
        public void setSource(String source) {
            this.source = source;
        }

        public String getDestination() { return destination; }
        public void setDestination(String destination) {
            this.destination = destination;
        }

        public LocalDate getRideDate() { return rideDate; }
        public void setRideDate(LocalDate rideDate) {
            this.rideDate = rideDate;
        }

        public LocalTime getRideTime() { return rideTime; }
        public void setRideTime(LocalTime rideTime) {
            this.rideTime = rideTime;
        }

        public Integer getAvailableSeats() { return availableSeats; }
        public void setAvailableSeats(Integer availableSeats) {
            this.availableSeats = availableSeats;
        }

        public BigDecimal getContribution() { return contribution; }
        public void setContribution(BigDecimal contribution) {
            this.contribution = contribution;
        }

        public String getVehicleDetails() { return vehicleDetails; }
        public void setVehicleDetails(String vehicleDetails) {
            this.vehicleDetails = vehicleDetails;
        }
    }
}
