
package com.university.smartride.service;

import com.university.smartride.dto.RegisterRequest;
import com.university.smartride.entity.User;
import com.university.smartride.repository.UserRepository;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RegistrationService {

    private final UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder =
            new BCryptPasswordEncoder();

    public RegistrationService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Transactional
    public User register(RegisterRequest request) {

        if (request.getUniversityId() == null
                || !request.getUniversityId().matches("(\\d{10}|\\d{4})")) {
            throw new IllegalArgumentException(
                    "Enter a 10-digit student roll number or a 4-digit staff ID.");
        }

        if (request.getFullName() == null
                || request.getFullName().isBlank()) {
            throw new IllegalArgumentException("Full name is required.");
        }

        if (request.getEmail() == null
                || !request.getEmail().matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {
            throw new IllegalArgumentException("Enter a valid email address.");
        }

        if (request.getPassword() == null
                || request.getPassword().length() < 8) {
            throw new IllegalArgumentException(
                    "Password must contain at least 8 characters.");
        }

        if (request.getUserType() == null) {
            throw new IllegalArgumentException("Select an account type.");
        }

        User.UserType userType;

        try {
            userType = User.UserType.valueOf(
                    request.getUserType().toUpperCase());
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException(
                    "Account type must be STUDENT or STAFF.");
        }

        if (userType == User.UserType.STUDENT
                && !request.getUniversityId().matches("\\d{10}")) {
            throw new IllegalArgumentException(
                    "Student roll number must contain exactly 10 digits.");
        }

        if (userType == User.UserType.STAFF
                && !request.getUniversityId().matches("\\d{4}")) {
            throw new IllegalArgumentException(
                    "Staff ID must contain exactly 4 digits.");
        }

        if (userRepository.findByUniversityId(
                request.getUniversityId()).isPresent()) {
            throw new IllegalArgumentException(
                    "This university ID is already registered.");
        }

        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            throw new IllegalArgumentException(
                    "This email address is already registered.");
        }

        User user = new User();
        user.setUniversityId(request.getUniversityId());
        user.setFullName(request.getFullName().trim());
        user.setEmail(request.getEmail().trim());
        user.setPhone(request.getPhone());
        user.setUserType(userType);
        user.setPassword(passwordEncoder.encode(request.getPassword()));

        return userRepository.save(user);
    }
}
