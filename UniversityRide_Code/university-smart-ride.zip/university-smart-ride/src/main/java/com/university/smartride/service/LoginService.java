
package com.university.smartride.service;

import com.university.smartride.dto.LoginRequest;
import com.university.smartride.entity.User;
import com.university.smartride.repository.UserRepository;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class LoginService {

    private final UserRepository userRepository;

    private final BCryptPasswordEncoder passwordEncoder =
            new BCryptPasswordEncoder();

    public LoginService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public User login(LoginRequest request) {

        if (request.getUniversityId() == null
                || request.getPassword() == null
                || request.getUniversityId().isBlank()
                || request.getPassword().isBlank()) {
            throw new IllegalArgumentException(
                    "University ID and password are required.");
        }

        User user = userRepository
                .findByUniversityId(request.getUniversityId().trim())
                .orElseThrow(() -> new IllegalArgumentException(
                        "Invalid University ID or password."));

        if (!passwordEncoder.matches(
                request.getPassword(), user.getPassword())) {
            throw new IllegalArgumentException(
                    "Invalid University ID or password.");
        }

        return user;
    }
}
