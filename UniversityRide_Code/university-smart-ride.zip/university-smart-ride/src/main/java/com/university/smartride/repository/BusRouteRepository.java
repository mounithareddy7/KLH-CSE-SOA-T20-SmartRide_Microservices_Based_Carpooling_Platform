
package com.university.smartride.repository;

import com.university.smartride.entity.BusRoute;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface BusRouteRepository
        extends JpaRepository<BusRoute, Integer> {

    List<BusRoute> findByAvailableTrue();

    List<BusRoute> findByStartingPointContainingIgnoreCase(
            String startingPoint);

    List<BusRoute> findByDestinationContainingIgnoreCase(
            String destination);
}
