
package com.university.smartride.service;

import com.university.smartride.entity.BusAttendance;
import com.university.smartride.entity.BusRoute;
import com.university.smartride.entity.User;
import com.university.smartride.repository.BusAttendanceRepository;
import com.university.smartride.repository.BusRouteRepository;
import com.university.smartride.repository.UserRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Service
public class BusAttendanceService {

    private final BusAttendanceRepository attendanceRepository;
    private final BusRouteRepository busRouteRepository;
    private final UserRepository userRepository;

    public BusAttendanceService(
            BusAttendanceRepository attendanceRepository,
            BusRouteRepository busRouteRepository,
            UserRepository userRepository) {
        this.attendanceRepository = attendanceRepository;
        this.busRouteRepository = busRouteRepository;
        this.userRepository = userRepository;
    }

    @Transactional
    public BusAttendance markPresent(
            Integer studentId,
            Integer busRouteId,
            Integer staffId) {

        User student = userRepository.findById(studentId)
                .orElseThrow(() ->
                        new IllegalArgumentException("Student not found."));

        if (student.getUserType() != User.UserType.STUDENT) {
            throw new IllegalArgumentException(
                    "The selected user is not a student.");
        }

        User staff = userRepository.findById(staffId)
                .orElseThrow(() ->
                        new IllegalArgumentException("Staff user not found."));

        if (staff.getUserType() != User.UserType.STAFF) {
            throw new IllegalArgumentException(
                    "Only staff can record bus attendance.");
        }

        BusRoute route = busRouteRepository.findById(busRouteId)
                .orElseThrow(() ->
                        new IllegalArgumentException("Bus route not found."));

        LocalDate today = LocalDate.now();

        boolean alreadyRecorded = attendanceRepository
                .findByBusRoute_IdAndAttendanceDate(busRouteId, today)
                .stream()
                .anyMatch(record ->
                        record.getStudent().getId().equals(studentId));

        if (alreadyRecorded) {
            throw new IllegalArgumentException(
                    "Attendance is already recorded for this student today on this route.");
        }

        BusAttendance attendance = new BusAttendance();
        attendance.setStudent(student);
        attendance.setBusRoute(route);
        attendance.setRecordedBy(staff);
        attendance.setAttendanceDate(today);
        attendance.setBoardingTime(LocalTime.now());
        attendance.setAttendanceStatus(
                BusAttendance.AttendanceStatus.PRESENT);

        return attendanceRepository.save(attendance);
    }

    public List<BusAttendance> getAttendanceByDate(LocalDate date) {
        return attendanceRepository.findByAttendanceDate(date);
    }
}
