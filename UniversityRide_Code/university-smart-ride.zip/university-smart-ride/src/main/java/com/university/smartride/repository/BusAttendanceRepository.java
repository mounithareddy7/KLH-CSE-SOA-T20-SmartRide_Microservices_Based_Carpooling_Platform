
package com.university.smartride.repository;

import com.university.smartride.entity.BusAttendance;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface BusAttendanceRepository
        extends JpaRepository<BusAttendance, Integer> {

    List<BusAttendance> findByAttendanceDate(LocalDate attendanceDate);

    List<BusAttendance> findByStudent_Id(Integer studentId);

    List<BusAttendance> findByBusRoute_IdAndAttendanceDate(
            Integer busRouteId,
            LocalDate attendanceDate
    );
}
