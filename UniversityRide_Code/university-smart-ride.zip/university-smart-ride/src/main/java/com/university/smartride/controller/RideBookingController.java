
package com.university.smartride.controller;

import com.university.smartride.entity.RideBooking;
import com.university.smartride.repository.RideBookingRepository;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/bookings")
public class RideBookingController {

    private final RideBookingRepository bookingRepository;

    public RideBookingController(
            RideBookingRepository bookingRepository) {
        this.bookingRepository = bookingRepository;
    }

    @GetMapping
    public List<RideBooking> getAllBookings() {
        return bookingRepository.findAll();
    }

    @GetMapping("/passenger/{passengerId}")
    public List<RideBooking> getBookingsByPassenger(
            @PathVariable Integer passengerId) {
        return bookingRepository.findByPassengerId(passengerId);
    }

    @GetMapping("/ride/{rideId}")
    public List<RideBooking> getBookingsByRide(
            @PathVariable Integer rideId) {
        return bookingRepository.findByRideId(rideId);
    }
}
