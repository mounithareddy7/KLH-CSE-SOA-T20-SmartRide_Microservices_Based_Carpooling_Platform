
package com.university.smartride.repository;

import com.university.smartride.entity.Ride;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;

public interface RideRepository extends JpaRepository<Ride, Integer> {

    List<Ride> findBySourceContainingIgnoreCaseAndDestinationContainingIgnoreCase(
            String source, String destination);

    List<Ride> findByRideDateAndStatus(
            LocalDate rideDate, Ride.RideStatus status);

}
