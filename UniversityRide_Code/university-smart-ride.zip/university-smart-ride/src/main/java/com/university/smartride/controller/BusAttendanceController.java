
package com.university.smartride.controller;

import com.university.smartride.entity.BusAttendance;
import com.university.smartride.service.BusAttendanceService;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/bus-attendance")
public class BusAttendanceController {

    private final BusAttendanceService attendanceService;

    public BusAttendanceController(
            BusAttendanceService attendanceService) {
        this.attendanceService = attendanceService;
    }

    @PostMapping("/mark")
    public ResponseEntity<?> markPresent(
            @RequestParam Integer studentId,
            @RequestParam Integer busRouteId,
            @RequestParam Integer staffId) {
        try {
            BusAttendance attendance = attendanceService.markPresent(
                    studentId, busRouteId, staffId);

            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(Map.of(
                            "message", "Attendance recorded successfully.",
                            "attendanceId", attendance.getId()
                    ));

        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest()
                    .body(Map.of("message", ex.getMessage()));
        }
    }

    @GetMapping
    public List<Map<String, Object>> getAttendanceByDate(
            @RequestParam
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate date) {

        return attendanceService.getAttendanceByDate(date)
                .stream()
                .map(attendance -> Map.<String, Object>of(
                        "attendanceId", attendance.getId(),
                        "studentId", attendance.getStudent().getUniversityId(),
                        "studentName", attendance.getStudent().getFullName(),
                        "routeNumber", attendance.getBusRoute().getRouteNumber(),
                        "attendanceDate", attendance.getAttendanceDate().toString(),
                        "boardingTime", attendance.getBoardingTime().toString(),
                        "status", attendance.getAttendanceStatus().name()
                ))
                .toList();
    }
}
