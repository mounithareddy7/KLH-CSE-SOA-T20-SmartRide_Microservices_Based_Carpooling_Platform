
package com.university.smartride.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalTime;
import java.time.LocalDateTime;

@Entity
@Table(name = "bus_routes")
public class BusRoute {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "route_number", nullable = false, length = 20)
    private String routeNumber;

    @Column(name = "route_name", nullable = false, length = 100)
    private String routeName;

    @Column(name = "starting_point", nullable = false, length = 150)
    private String startingPoint;

    @Column(nullable = false, length = 150)
    private String destination;

    @Column(name = "bus_time")
    private LocalTime busTime;

    @Column(name = "arrival_time")
    private LocalTime arrivalTime;

    @Column(name = "bus_fee", precision = 8, scale = 2)
    private BigDecimal busFee = BigDecimal.ZERO;

    @Column(name = "available")
    private Boolean available = true;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    public BusRoute() {
    }

    public Integer getId() { return id; }

    public String getRouteNumber() { return routeNumber; }
    public void setRouteNumber(String routeNumber) {
        this.routeNumber = routeNumber;
    }

    public String getRouteName() { return routeName; }
    public void setRouteName(String routeName) {
        this.routeName = routeName;
    }

    public String getStartingPoint() { return startingPoint; }
    public void setStartingPoint(String startingPoint) {
        this.startingPoint = startingPoint;
    }

    public String getDestination() { return destination; }
    public void setDestination(String destination) {
        this.destination = destination;
    }

    public LocalTime getBusTime() { return busTime; }
    public void setBusTime(LocalTime busTime) {
        this.busTime = busTime;
    }

    public LocalTime getArrivalTime() { return arrivalTime; }
    public void setArrivalTime(LocalTime arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public BigDecimal getBusFee() { return busFee; }
    public void setBusFee(BigDecimal busFee) {
        this.busFee = busFee;
    }

    public Boolean getAvailable() { return available; }
    public void setAvailable(Boolean available) {
        this.available = available;
    }

    public LocalDateTime getCreatedAt() { return createdAt; }
}
