
package com.university.smartride.controller;

import com.university.smartride.entity.BusStop;
import com.university.smartride.repository.BusStopRepository;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/bus-stops")
public class BusStopController {

    private final BusStopRepository busStopRepository;

    public BusStopController(BusStopRepository busStopRepository) {
        this.busStopRepository = busStopRepository;
    }

    @GetMapping("/route/{routeId}")
    public List<BusStop> getStopsByRoute(
            @PathVariable Integer routeId) {

        return busStopRepository
                .findByRouteIdOrderByStopOrderAsc(routeId);
    }
}
