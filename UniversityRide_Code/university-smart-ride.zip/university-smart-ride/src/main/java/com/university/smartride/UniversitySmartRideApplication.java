package com.university.smartride;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UniversitySmartRideApplication {

	public static void main(String[] args) {
		SpringApplication.run(UniversitySmartRideApplication.class, args);
	}

}
