
package com.university.smartride.controller;

import com.university.smartride.entity.BusRoute;
import com.university.smartride.repository.BusRouteRepository;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/bus-routes")
public class BusRouteController {

    private final BusRouteRepository busRouteRepository;

    public BusRouteController(BusRouteRepository busRouteRepository) {
        this.busRouteRepository = busRouteRepository;
    }

    @GetMapping
    public List<BusRoute> getAllRoutes() {
        return busRouteRepository.findAll();
    }

    @GetMapping("/available")
    public List<BusRoute> getAvailableRoutes() {
        return busRouteRepository.findByAvailableTrue();
    }

    @GetMapping("/search")
    public List<BusRoute> searchByStartingPoint(
            @RequestParam String startingPoint) {

        return busRouteRepository
                .findByStartingPointContainingIgnoreCase(startingPoint);
    }
}
