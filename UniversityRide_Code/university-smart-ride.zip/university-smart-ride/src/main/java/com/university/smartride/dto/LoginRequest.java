
package com.university.smartride.dto;

public class LoginRequest {

    private String universityId;
    private String password;

    public LoginRequest() {
    }

    public String getUniversityId() {
        return universityId;
    }

    public void setUniversityId(String universityId) {
        this.universityId = universityId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
