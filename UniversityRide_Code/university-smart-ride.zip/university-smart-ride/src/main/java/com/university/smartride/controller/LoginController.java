
package com.university.smartride.controller;

import com.university.smartride.dto.LoginRequest;
import com.university.smartride.entity.User;
import com.university.smartride.service.LoginService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class LoginController {

    private final LoginService loginService;

    public LoginController(LoginService loginService) {
        this.loginService = loginService;
    }

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(
            @RequestBody LoginRequest request) {

        try {
            User user = loginService.login(request);

            return ResponseEntity.ok(Map.of(
                    "message", "Login successful!",
                    "universityId", user.getUniversityId(),
                    "fullName", user.getFullName(),
                    "userType", user.getUserType().name()
            ));

        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(
                    Map.of("message", ex.getMessage()));
        }
    }
}
