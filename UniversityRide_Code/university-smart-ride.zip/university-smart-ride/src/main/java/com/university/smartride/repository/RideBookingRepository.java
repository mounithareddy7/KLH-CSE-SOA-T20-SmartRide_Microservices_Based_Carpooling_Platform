
package com.university.smartride.repository;

import com.university.smartride.entity.RideBooking;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface RideBookingRepository
        extends JpaRepository<RideBooking, Integer> {

    List<RideBooking> findByPassengerId(Integer passengerId);

    List<RideBooking> findByRideId(Integer rideId);

    boolean existsByRideIdAndPassengerId(
            Integer rideId, Integer passengerId);
}
