
package com.university.smartride.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;

@Entity
@Table(name = "rides")
public class Ride {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "driver_id", nullable = false)
    private User driver;

    @Column(nullable = false, length = 150)
    private String source;

    @Column(nullable = false, length = 150)
    private String destination;

    @Column(name = "ride_date", nullable = false)
    private LocalDate rideDate;

    @Column(name = "ride_time", nullable = false)
    private LocalTime rideTime;

    @Column(name = "available_seats", nullable = false)
    private Integer availableSeats;

    @Column(precision = 8, scale = 2)
    private BigDecimal contribution = BigDecimal.ZERO;

    @Column(name = "vehicle_details", length = 100)
    private String vehicleDetails;

    @Enumerated(EnumType.STRING)
    private RideStatus status = RideStatus.AVAILABLE;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    public enum RideStatus {
        AVAILABLE, FULL, CANCELLED
    }

    public Ride() {
    }

    public Integer getId() { return id; }

    public User getDriver() { return driver; }
    public void setDriver(User driver) { this.driver = driver; }

    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }

    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }

    public LocalDate getRideDate() { return rideDate; }
    public void setRideDate(LocalDate rideDate) { this.rideDate = rideDate; }

    public LocalTime getRideTime() { return rideTime; }
    public void setRideTime(LocalTime rideTime) { this.rideTime = rideTime; }

    public Integer getAvailableSeats() { return availableSeats; }
    public void setAvailableSeats(Integer availableSeats) { this.availableSeats = availableSeats; }

    public BigDecimal getContribution() { return contribution; }
    public void setContribution(BigDecimal contribution) { this.contribution = contribution; }

    public String getVehicleDetails() { return vehicleDetails; }
    public void setVehicleDetails(String vehicleDetails) { this.vehicleDetails = vehicleDetails; }

    public RideStatus getStatus() { return status; }
    public void setStatus(RideStatus status) { this.status = status; }

    public LocalDateTime getCreatedAt() { return createdAt; }
}
