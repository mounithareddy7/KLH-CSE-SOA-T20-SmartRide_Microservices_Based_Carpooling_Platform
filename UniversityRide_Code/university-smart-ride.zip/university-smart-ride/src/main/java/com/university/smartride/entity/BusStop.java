
package com.university.smartride.entity;

import jakarta.persistence.*;
import java.time.LocalTime;

@Entity
@Table(
    name = "bus_stops",
    uniqueConstraints = @UniqueConstraint(
        columnNames = {"route_id", "stop_order"}
    )
)
public class BusStop {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "route_id", nullable = false)
    private BusRoute route;

    @Column(name = "stop_name", nullable = false, length = 150)
    private String stopName;

    @Column(name = "stop_time")
    private LocalTime stopTime;

    @Column(name = "stop_order", nullable = false)
    private Integer stopOrder;

    public BusStop() {
    }

    public Integer getId() {
        return id;
    }

    public BusRoute getRoute() {
        return route;
    }

    public void setRoute(BusRoute route) {
        this.route = route;
    }

    public String getStopName() {
        return stopName;
    }

    public void setStopName(String stopName) {
        this.stopName = stopName;
    }

    public LocalTime getStopTime() {
        return stopTime;
    }

    public void setStopTime(LocalTime stopTime) {
        this.stopTime = stopTime;
    }

    public Integer getStopOrder() {
        return stopOrder;
    }

    public void setStopOrder(Integer stopOrder) {
        this.stopOrder = stopOrder;
    }
}
