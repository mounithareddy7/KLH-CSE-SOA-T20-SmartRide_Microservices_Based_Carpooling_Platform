package com.university.smartride;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniversitySmartRideApplicationTests {

	@Test
	void contextLoads() {
	}

}
