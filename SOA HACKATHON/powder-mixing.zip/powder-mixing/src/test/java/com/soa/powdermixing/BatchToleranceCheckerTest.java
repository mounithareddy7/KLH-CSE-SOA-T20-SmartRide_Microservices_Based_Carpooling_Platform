
package com.soa.powdermixing;

import com.soa.powdermixing.domain.IngredientWeighing;
import static org.assertj.core.api.Assertions.assertThat;
import com.soa.powdermixing.domain.BatchEvaluationService;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.soa.powdermixing.domain.BatchToleranceChecker;
import com.soa.powdermixing.domain.IngredientTolerance;

class BatchToleranceCheckerTest {

    private final BatchToleranceChecker checker =
            new BatchToleranceChecker();

    @Test
    void acceptsBatchWhenAllIngredientsAreWithinTolerance() {
        var ingredients = List.of(
                new IngredientTolerance("Ingredient A", 40, 2),
                new IngredientTolerance("Ingredient B", 60, 2));

        var actualPercentages = List.of(40.0, 60.0);

        assertThat(checker.isBatchWithinTolerance(
                ingredients, actualPercentages)).isTrue();
    }

    @Test
    void rejectsBatchWhenIngredientIsOutsideToleranceEvenIfTotalIs100() {
        var ingredients = List.of(
                new IngredientTolerance("Ingredient A", 40, 2),
                new IngredientTolerance("Ingredient B", 60, 2));

        // Total = 100%, but both ingredients violate their tolerances.
        var actualPercentages = List.of(43.0, 57.0);

        assertThat(actualPercentages.stream()
                .mapToDouble(Double::doubleValue)
                .sum()).isEqualTo(100.0);

        assertThat(checker.isBatchWithinTolerance(
                ingredients, actualPercentages)).isFalse();
    }
    
    @Test
    void calculatesIngredientPercentageFromActualWeight() {
        IngredientWeighing ingredient =
                new IngredientWeighing("Ingredient A", 400);

        double percentage = ingredient.calculatePercentage(1000);

        assertThat(percentage).isEqualTo(40.0);
    }

@Test
void rejectsBatchWithCorrectTotalWeightButInvalidIngredientProportions() {
    var recipe = List.of(
            new IngredientTolerance("Ingredient A", 40, 2),
            new IngredientTolerance("Ingredient B", 60, 2));

    var weighings = List.of(
            new IngredientWeighing("Ingredient A", 430),
            new IngredientWeighing("Ingredient B", 570));

    BatchEvaluationService service = new BatchEvaluationService();

    assertThat(weighings.stream()
            .mapToDouble(IngredientWeighing::getActualWeight)
            .sum()).isEqualTo(1000.0);

    assertThat(service.evaluateBatch(recipe, weighings)).isFalse();
}

}
