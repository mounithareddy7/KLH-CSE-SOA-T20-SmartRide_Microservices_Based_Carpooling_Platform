
package com.soa.powdermixing.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.soa.powdermixing.entity.BatchIngredient;

public interface BatchIngredientRepository
        extends JpaRepository<BatchIngredient, Long> {

    List<BatchIngredient> findByBatchBatchId(String batchId);
}
