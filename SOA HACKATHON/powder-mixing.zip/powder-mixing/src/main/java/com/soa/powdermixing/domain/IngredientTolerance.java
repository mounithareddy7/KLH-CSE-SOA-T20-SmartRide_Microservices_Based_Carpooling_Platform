
package com.soa.powdermixing.domain;

public class IngredientTolerance {

    private final String ingredientName;
    private final double targetPercentage;
    private final double tolerancePercentage;

    public IngredientTolerance(
            String ingredientName,
            double targetPercentage,
            double tolerancePercentage) {

        if (ingredientName == null || ingredientName.isBlank()) {
            throw new IllegalArgumentException(
                    "Ingredient name cannot be empty");
        }

        if (!Double.isFinite(targetPercentage)
                || targetPercentage < 0
                || targetPercentage > 100) {
            throw new IllegalArgumentException(
                    "Target percentage must be between 0 and 100");
        }

        if (!Double.isFinite(tolerancePercentage)
                || tolerancePercentage < 0
                || tolerancePercentage > 100) {
            throw new IllegalArgumentException(
                    "Tolerance must be between 0 and 100");
        }

        this.ingredientName = ingredientName;
        this.targetPercentage = targetPercentage;
        this.tolerancePercentage = tolerancePercentage;
    }

    public boolean isWithinTolerance(double actualPercentage) {

        if (!Double.isFinite(actualPercentage)
                || actualPercentage < 0
                || actualPercentage > 100) {
            return false;
        }

        double minimum = targetPercentage - tolerancePercentage;
        double maximum = targetPercentage + tolerancePercentage;

        return actualPercentage >= minimum
                && actualPercentage <= maximum;
    }

    public String getIngredientName() {
        return ingredientName;
    }

    public double getTargetPercentage() {
        return targetPercentage;
    }

    public double getTolerancePercentage() {
        return tolerancePercentage;
    }
}
