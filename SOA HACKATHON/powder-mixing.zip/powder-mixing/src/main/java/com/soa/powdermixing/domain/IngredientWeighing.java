
package com.soa.powdermixing.domain;

public class IngredientWeighing {

    private final String ingredientName;
    private final double actualWeight;

    public IngredientWeighing(
            String ingredientName,
            double actualWeight) {

        if (ingredientName == null || ingredientName.isBlank()) {
            throw new IllegalArgumentException(
                    "Ingredient name cannot be empty");
        }

        if (!Double.isFinite(actualWeight) || actualWeight <= 0) {
            throw new IllegalArgumentException(
                    "Actual weight must be greater than zero");
        }

        this.ingredientName = ingredientName;
        this.actualWeight = actualWeight;
    }

    public String getIngredientName() {
        return ingredientName;
    }

    public double getActualWeight() {
        return actualWeight;
    }

    public double calculatePercentage(double totalBatchWeight) {
        if (!Double.isFinite(totalBatchWeight)
                || totalBatchWeight <= 0) {
            throw new IllegalArgumentException(
                    "Total batch weight must be greater than zero");
        }

        if (actualWeight > totalBatchWeight) {
            throw new IllegalArgumentException(
                    "Ingredient weight cannot exceed total batch weight");
        }

        return (actualWeight / totalBatchWeight) * 100.0;
    }
}
