
package com.soa.powdermixing.entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "batches")
public class Batch {

    @Id
    private String batchId;

    private String decision;
    private String message;

    @OneToMany(
        mappedBy = "batch",
        cascade = CascadeType.ALL,
        orphanRemoval = true
    )
    private List<BatchIngredient> ingredients = new ArrayList<>();

    public Batch() {
    }

    public Batch(String batchId, String decision, String message) {
        this.batchId = batchId;
        this.decision = decision;
        this.message = message;
    }

    public void addIngredient(BatchIngredient ingredient) {
        ingredients.add(ingredient);
        ingredient.setBatch(this);
    }

    public String getBatchId() {
        return batchId;
    }

    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }

    public String getDecision() {
        return decision;
    }

    public void setDecision(String decision) {
        this.decision = decision;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<BatchIngredient> getIngredients() {
        return ingredients;
    }
}
