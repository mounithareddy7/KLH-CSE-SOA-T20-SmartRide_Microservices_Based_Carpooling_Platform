
package com.soa.powdermixing.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.soa.powdermixing.entity.Recipe;

public interface RecipeRepository
        extends JpaRepository<Recipe, String> {
}
