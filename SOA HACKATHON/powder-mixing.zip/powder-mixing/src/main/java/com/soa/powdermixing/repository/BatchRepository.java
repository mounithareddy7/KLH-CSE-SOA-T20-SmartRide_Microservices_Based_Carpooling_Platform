
package com.soa.powdermixing.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.soa.powdermixing.entity.Batch;

public interface BatchRepository extends JpaRepository<Batch, String> {
}
