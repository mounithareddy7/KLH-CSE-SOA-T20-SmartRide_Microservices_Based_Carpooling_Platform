
package com.soa.powdermixing.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.soa.powdermixing.entity.RecipeIngredient;

public interface RecipeIngredientRepository
        extends JpaRepository<RecipeIngredient, Long> {

    List<RecipeIngredient> findByRecipeRecipeId(String recipeId);
}
