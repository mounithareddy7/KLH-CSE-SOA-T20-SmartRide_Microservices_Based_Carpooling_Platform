
package com.soa.powdermixing.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "batch_ingredients")
public class BatchIngredient {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String ingredientName;
    private double targetPercentage;
    private double tolerancePercentage;
    private double actualWeight;
    private double actualPercentage;

    @ManyToOne
    @JoinColumn(name = "batch_id", nullable = false)
    private Batch batch;

    public BatchIngredient() {
    }

    public BatchIngredient(
            String ingredientName,
            double targetPercentage,
            double tolerancePercentage,
            double actualWeight,
            double actualPercentage,
            Batch batch) {

        this.ingredientName = ingredientName;
        this.targetPercentage = targetPercentage;
        this.tolerancePercentage = tolerancePercentage;
        this.actualWeight = actualWeight;
        this.actualPercentage = actualPercentage;
        this.batch = batch;
    }

    public Long getId() {
        return id;
    }

    public String getIngredientName() {
        return ingredientName;
    }

    public double getTargetPercentage() {
        return targetPercentage;
    }

    public double getTolerancePercentage() {
        return tolerancePercentage;
    }

    public double getActualWeight() {
        return actualWeight;
    }

    public double getActualPercentage() {
        return actualPercentage;
    }

    public Batch getBatch() {
        return batch;
    }

    public void setBatch(Batch batch) {
        this.batch = batch;
    }
}
