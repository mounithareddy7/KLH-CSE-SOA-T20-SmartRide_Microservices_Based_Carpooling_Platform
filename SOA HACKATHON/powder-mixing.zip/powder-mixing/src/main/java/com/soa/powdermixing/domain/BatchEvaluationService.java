
package com.soa.powdermixing.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BatchEvaluationService {

    private final BatchToleranceChecker toleranceChecker =
            new BatchToleranceChecker();

    public boolean evaluateBatch(
            List<IngredientTolerance> recipe,
            List<IngredientWeighing> weighings) {

        if (recipe == null || weighings == null) {
            throw new IllegalArgumentException(
                    "Recipe and weighings are required");
        }

        if (recipe.isEmpty() || recipe.size() != weighings.size()) {
            throw new IllegalArgumentException(
                    "Recipe and weighing lists must match and not be empty");
        }

        Map<String, IngredientTolerance> recipeMap = new HashMap<>();

        for (IngredientTolerance ingredient : recipe) {
            if (ingredient == null) {
                throw new IllegalArgumentException(
                        "Recipe ingredients cannot be null");
            }

            String name = ingredient.getIngredientName()
                    .trim().toLowerCase();

            if (recipeMap.put(name, ingredient) != null) {
                throw new IllegalArgumentException(
                        "Duplicate ingredient in recipe: "
                                + ingredient.getIngredientName());
            }
        }

        Map<String, IngredientWeighing> weighingMap = new HashMap<>();
        double totalWeight = 0.0;

        for (IngredientWeighing weighing : weighings) {
            if (weighing == null) {
                throw new IllegalArgumentException(
                        "Weighing entries cannot be null");
            }

            String name = weighing.getIngredientName()
                    .trim().toLowerCase();

            if (weighingMap.put(name, weighing) != null) {
                throw new IllegalArgumentException(
                        "Duplicate ingredient weighing: "
                                + weighing.getIngredientName());
            }

            if (!recipeMap.containsKey(name)) {
                throw new IllegalArgumentException(
                        "Ingredient not found in recipe: "
                                + weighing.getIngredientName());
            }

            totalWeight += weighing.getActualWeight();
        }

        if (weighingMap.size() != recipeMap.size()) {
            throw new IllegalArgumentException(
                    "Recipe and weighing ingredient names must match");
        }

        if (!Double.isFinite(totalWeight) || totalWeight <= 0) {
            throw new IllegalArgumentException(
                    "Total batch weight must be valid and positive");
        }

        List<IngredientTolerance> orderedRecipe = new ArrayList<>();
        List<Double> actualPercentages = new ArrayList<>();

        for (IngredientTolerance ingredient : recipe) {
            String name = ingredient.getIngredientName()
                    .trim().toLowerCase();

            IngredientWeighing weighing = weighingMap.get(name);

            orderedRecipe.add(ingredient);
            actualPercentages.add(
                    weighing.calculatePercentage(totalWeight));
        }

        return toleranceChecker.isBatchWithinTolerance(
                orderedRecipe, actualPercentages);
    }
}
