
package com.soa.powdermixing.domain;

import java.util.List;

public class BatchToleranceChecker {

    public boolean isBatchWithinTolerance(
            List<IngredientTolerance> ingredients,
            List<Double> actualPercentages) {

        if (ingredients == null || actualPercentages == null) {
            throw new IllegalArgumentException(
                    "Ingredients and actual percentages are required");
        }

        if (ingredients.isEmpty()
                || ingredients.size() != actualPercentages.size()) {
            throw new IllegalArgumentException(
                    "Ingredient and percentage lists must match and not be empty");
        }

        for (int i = 0; i < ingredients.size(); i++) {
            IngredientTolerance ingredient = ingredients.get(i);
            Double actualPercentage = actualPercentages.get(i);

            if (ingredient == null || actualPercentage == null) {
                throw new IllegalArgumentException(
                        "Ingredient and percentage values cannot be null");
            }

            if (!ingredient.isWithinTolerance(actualPercentage)) {
                return false;
            }
        }

        return true;
    }
}
