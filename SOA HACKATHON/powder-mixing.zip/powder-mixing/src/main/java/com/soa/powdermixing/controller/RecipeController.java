
package com.soa.powdermixing.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.http.HttpStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.soa.powdermixing.entity.Recipe;
import com.soa.powdermixing.entity.RecipeIngredient;
import com.soa.powdermixing.repository.RecipeRepository;

@RestController
@RequestMapping("/api/recipes")
public class RecipeController {

    private final RecipeRepository recipeRepository;

    public RecipeController(RecipeRepository recipeRepository) {
        this.recipeRepository = recipeRepository;
    }

    @PostMapping
    public Recipe createRecipe(@RequestBody Recipe recipe) {
        validateRecipe(recipe);

        if (recipeRepository.existsById(recipe.getRecipeId())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT, "Recipe ID already exists");
        }

        setRecipeIngredients(recipe);
        return recipeRepository.save(recipe);
    }

    @GetMapping
    public List<Recipe> getAllRecipes() {
        return recipeRepository.findAll();
    }

    @GetMapping("/{recipeId}")
    public Recipe getRecipe(@PathVariable String recipeId) {
        return recipeRepository.findById(recipeId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Recipe not found"));
    }

    @PutMapping("/{recipeId}")
    @Transactional
    public Recipe updateRecipe(
            @PathVariable String recipeId,
            @RequestBody Recipe updatedRecipe) {

        Recipe existingRecipe = recipeRepository.findById(recipeId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Recipe not found"));

        if (updatedRecipe == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, "Recipe body is required");
        }

        if (updatedRecipe.getRecipeId() != null
                && !updatedRecipe.getRecipeId().equals(recipeId)) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Recipe ID in the body must match the URL");
        }

        validateRecipe(updatedRecipe);

        existingRecipe.setRecipeName(updatedRecipe.getRecipeName());
        existingRecipe.setVersion(updatedRecipe.getVersion());

        existingRecipe.getIngredients().clear();

        for (RecipeIngredient ingredient : updatedRecipe.getIngredients()) {
            existingRecipe.addIngredient(ingredient);
        }

        return recipeRepository.save(existingRecipe);
    }

    @DeleteMapping("/{recipeId}")
    public void deleteRecipe(@PathVariable String recipeId) {
        Recipe recipe = recipeRepository.findById(recipeId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Recipe not found"));

        recipeRepository.delete(recipe);
    }

    private void validateRecipe(Recipe recipe) {
        if (recipe == null
                || recipe.getRecipeId() == null
                || recipe.getRecipeId().isBlank()
                || recipe.getRecipeName() == null
                || recipe.getRecipeName().isBlank()
                || recipe.getVersion() < 1) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Recipe ID, name and a positive version are required");
        }

        if (recipe.getIngredients() == null
                || recipe.getIngredients().isEmpty()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "At least one ingredient is required");
        }

        Set<String> ingredientNames = new HashSet<>();
        double totalTargetPercentage = 0.0;

        for (RecipeIngredient ingredient : recipe.getIngredients()) {
            if (ingredient == null
                    || ingredient.getIngredientName() == null
                    || ingredient.getIngredientName().isBlank()
                    || !Double.isFinite(ingredient.getTargetPercentage())
                    || !Double.isFinite(ingredient.getTolerancePercentage())
                    || ingredient.getTargetPercentage() <= 0
                    || ingredient.getTargetPercentage() > 100
                    || ingredient.getTolerancePercentage() < 0
                    || ingredient.getTolerancePercentage() > 100
                    || ingredient.getTargetPercentage()
                            + ingredient.getTolerancePercentage() > 100) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Each ingredient must have a name, positive target, and valid tolerance");
            }

            String normalizedName = ingredient.getIngredientName()
                    .trim().toLowerCase(java.util.Locale.ROOT);

            if (!ingredientNames.add(normalizedName)) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Duplicate ingredient: " + ingredient.getIngredientName());
            }

            totalTargetPercentage += ingredient.getTargetPercentage();
        }

        if (Math.abs(totalTargetPercentage - 100.0) > 0.000001) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Ingredient target percentages must total 100%");
        }
    }

    private void setRecipeIngredients(Recipe recipe) {
        for (RecipeIngredient ingredient : recipe.getIngredients()) {
            ingredient.setRecipe(recipe);
        }
    }
}
