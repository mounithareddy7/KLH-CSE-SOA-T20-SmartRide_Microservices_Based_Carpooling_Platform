
package com.soa.powdermixing.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.springframework.http.HttpStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.soa.powdermixing.domain.BatchEvaluationService;
import com.soa.powdermixing.domain.IngredientTolerance;
import com.soa.powdermixing.domain.IngredientWeighing;
import com.soa.powdermixing.entity.Batch;
import com.soa.powdermixing.entity.BatchIngredient;
import com.soa.powdermixing.repository.BatchRepository;

@RestController
@RequestMapping("/api/batches")
public class BatchController {

    private final BatchEvaluationService evaluationService =
            new BatchEvaluationService();

    private final BatchRepository batchRepository;

    public BatchController(BatchRepository batchRepository) {
        this.batchRepository = batchRepository;
    }

    @PostMapping("/evaluate")
    @Transactional
    public BatchEvaluationResponse evaluateBatch(
            @RequestBody BatchEvaluationRequest request) {

        if (request == null
                || request.batchId() == null
                || request.batchId().isBlank()
                || request.ingredients() == null
                || request.ingredients().isEmpty()) {

            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Batch ID and ingredients are required");
        }

        if (batchRepository.existsById(request.batchId())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Batch ID already exists");
        }

        Set<String> ingredientNames = new HashSet<>();

        for (IngredientInput ingredient : request.ingredients()) {

            if (ingredient == null) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Ingredient entries cannot be null");
            }

            if (ingredient.name() == null
                    || ingredient.name().isBlank()) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Ingredient name cannot be empty");
            }

            String normalizedName = ingredient.name()
                    .trim()
                    .toLowerCase(Locale.ROOT);

            if (!ingredientNames.add(normalizedName)) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Duplicate ingredient: " + ingredient.name());
            }
        }

        try {
            List<IngredientTolerance> recipe =
                    request.ingredients().stream()
                            .map(i -> new IngredientTolerance(
                                    i.name(),
                                    i.targetPercentage(),
                                    i.tolerancePercentage()))
                            .toList();

            List<IngredientWeighing> weighings =
                    request.ingredients().stream()
                            .map(i -> new IngredientWeighing(
                                    i.name(),
                                    i.actualWeight()))
                            .toList();

            boolean approved = evaluationService.evaluateBatch(
                    recipe, weighings);

            double totalWeight = weighings.stream()
                    .mapToDouble(IngredientWeighing::getActualWeight)
                    .sum();

            String decision = approved ? "APPROVED" : "REJECTED";

            String message = approved
                    ? "All ingredients are within tolerance"
                    : "One or more ingredients are outside tolerance";

            Batch batch = new Batch(
                    request.batchId(), decision, message);

            for (IngredientInput input : request.ingredients()) {

                double actualPercentage =
                        (input.actualWeight() / totalWeight) * 100.0;

                BatchIngredient ingredient = new BatchIngredient(
                        input.name(),
                        input.targetPercentage(),
                        input.tolerancePercentage(),
                        input.actualWeight(),
                        actualPercentage,
                        batch);

                batch.addIngredient(ingredient);
            }

            batchRepository.save(batch);

            return new BatchEvaluationResponse(
                    decision, request.batchId(), message);

        } catch (IllegalArgumentException ex) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, ex.getMessage());
        }
    }

    public record BatchEvaluationRequest(
            String batchId,
            List<IngredientInput> ingredients) {
    }

    public record IngredientInput(
            String name,
            double targetPercentage,
            double tolerancePercentage,
            double actualWeight) {
    }

    public record BatchEvaluationResponse(
            String decision,
            String batchId,
            String message) {
    }
}
