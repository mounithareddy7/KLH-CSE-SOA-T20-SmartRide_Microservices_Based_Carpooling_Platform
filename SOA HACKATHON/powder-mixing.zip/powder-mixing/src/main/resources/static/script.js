
const API = {
    recipes: "/api/recipes",
    evaluate: "/api/batches/evaluate"
};

let recipes = [];
let batchHistory = [];
let editingRecipeId = null;

const $ = (id) => document.getElementById(id);

/* API request helper */

async function apiRequest(url, options = {}) {
    const response = await fetch(url, {
        ...options,
        headers: {
            "Content-Type": "application/json",
            ...(options.headers || {})
        }
    });

    const text = await response.text();
    let data = null;

    if (text) {
        try {
            data = JSON.parse(text);
        } catch {
            data = text;
        }
    }

    if (!response.ok) {
        const message =
            data?.detail ||
            data?.message ||
            data?.title ||
            (typeof data === "string" ? data : null) ||
            `Request failed (${response.status})`;

        throw new Error(message);
    }

    return data;
}

/* Messages and helper functions */

function showMessage(id, message, type = "info") {
    const element = $(id);
    if (!element) return;

    element.textContent = message;
    element.className = `message ${type}`;
}

function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[char]);
}

function getRecipeId(recipe) {
    return recipe.recipeId ?? recipe.id ?? "";
}

function getRecipeName(recipe) {
    return recipe.recipeName ?? recipe.name ?? "";
}

function getIngredients(recipe) {
    return Array.isArray(recipe.ingredients) ? recipe.ingredients : [];
}

function getIngredientName(ingredient) {
    return ingredient.ingredientName ?? ingredient.name ?? "";
}

function getNumber(value) {
    return Number(value);
}

/* Recipe ingredient rows */

function addIngredientRow(ingredient = {}) {
    const tbody = $("recipeIngredients");
    const row = document.createElement("tr");

    row.className = "ingredient-row";

    row.innerHTML = `
        <td>
            <input class="ingredient-name" type="text"
                placeholder="Ingredient name" required>
        </td>
        <td>
            <input class="target-percent" type="number"
                min="0.01" max="100" step="any"
                placeholder="Target %" required>
        </td>
        <td>
            <input class="tolerance-percent" type="number"
                min="0" max="100" step="any"
                value="5" required>
        </td>
        <td>
            <button type="button" class="btn-remove"
                onclick="removeIngredient(this)">Remove</button>
        </td>
    `;

    row.querySelector(".ingredient-name").value =
        ingredient.ingredientName ?? ingredient.name ?? "";

    row.querySelector(".target-percent").value =
        ingredient.targetPercentage ?? "";

    row.querySelector(".tolerance-percent").value =
        ingredient.tolerancePercentage ?? 5;

    tbody.appendChild(row);
    updateTargetTotal();
}

function removeIngredient(button) {
    const rows = document.querySelectorAll(
        "#recipeIngredients .ingredient-row"
    );

    if (rows.length <= 1) {
        showMessage(
            "recipeMessage",
            "At least one ingredient is required.",
            "error"
        );
        return;
    }

    button.closest("tr").remove();
    updateTargetTotal();
}

function readRecipeIngredients() {
    return [...document.querySelectorAll(
        "#recipeIngredients .ingredient-row"
    )].map(row => ({
        ingredientName:
            row.querySelector(".ingredient-name").value.trim(),

        targetPercentage: getNumber(
            row.querySelector(".target-percent").value
        ),

        tolerancePercentage: getNumber(
            row.querySelector(".tolerance-percent").value
        )
    }));
}

function updateTargetTotal() {
    const ingredients = readRecipeIngredients();

    const total = ingredients.reduce((sum, item) => {
        return sum + (
            Number.isFinite(item.targetPercentage)
                ? item.targetPercentage
                : 0
        );
    }, 0);

    $("targetTotal").textContent =
        `${Number(total.toFixed(4))}%`;

    $("targetTotal").style.color =
        Math.abs(total - 100) < 0.0001
            ? "#4f8064"
            : "#c66b3d";
}

/* Validate recipe ingredients */

function validateIngredients(ingredients) {
    if (ingredients.length === 0) {
        throw new Error("Add at least one ingredient.");
    }

    const names = new Set();
    let total = 0;

    for (const item of ingredients) {
        const name = String(
            item.ingredientName ?? item.name ?? ""
        ).trim();

        if (!name) {
            throw new Error("Ingredient names cannot be empty.");
        }

        const key = name.toLowerCase();

        if (names.has(key)) {
            throw new Error(`Duplicate ingredient: ${name}`);
        }

        names.add(key);

        const target = Number(item.targetPercentage);
        const tolerance = Number(item.tolerancePercentage);

        if (
            !Number.isFinite(target) ||
            target <= 0 ||
            target > 100
        ) {
            throw new Error(
                "Each target must be greater than 0 and at most 100%."
            );
        }

        if (
            !Number.isFinite(tolerance) ||
            tolerance < 0 ||
            tolerance > 100 ||
            target + tolerance > 100
        ) {
            throw new Error("Please check the tolerance values.");
        }

        total += target;
    }

    if (Math.abs(total - 100) > 0.0001) {
        throw new Error(
            `Target percentages must total 100%. Current total: ${total}%.`
        );
    }
}

/* Reset and edit recipes */

function resetRecipeForm() {
    $("recipeForm").reset();
    $("recipeId").disabled = false;
    $("recipeVersion").value = 1;
    $("recipeIngredients").innerHTML = "";

    addIngredientRow();

    editingRecipeId = null;

    const submitButton = $("recipeForm").querySelector(
        'button[type="submit"]'
    );

    submitButton.textContent = "Save Recipe";
    updateTargetTotal();
}

function editRecipe(id) {
    const recipe = recipes.find(
        item => String(getRecipeId(item)) === String(id)
    );

    if (!recipe) {
        showMessage("listMessage", "Recipe not found.", "error");
        return;
    }

    editingRecipeId = String(getRecipeId(recipe));

    $("recipeId").value = editingRecipeId;
    $("recipeId").disabled = true;
    $("recipeName").value = getRecipeName(recipe);
    $("recipeVersion").value = recipe.version ?? 1;
    $("recipeIngredients").innerHTML = "";

    const ingredients = getIngredients(recipe);

    if (ingredients.length) {
        ingredients.forEach(addIngredientRow);
    } else {
        addIngredientRow();
    }

    $("recipeForm").querySelector(
        'button[type="submit"]'
    ).textContent = "Update Recipe";

    updateTargetTotal();

    $("recipes").scrollIntoView({ behavior: "smooth" });

    showMessage(
        "recipeMessage",
        "Edit the details and click Update Recipe.",
        "info"
    );
}

/* Save or update recipe */

async function saveRecipe(event) {
    event.preventDefault();

    try {
        const ingredients = readRecipeIngredients();
        validateIngredients(ingredients);

        const id = $("recipeId").value.trim();
        const name = $("recipeName").value.trim();
        const version = Number($("recipeVersion").value);

        if (!id || !name) {
            throw new Error("Recipe ID and name are required.");
        }

        if (!Number.isInteger(version) || version < 1) {
            throw new Error("Version must be a positive whole number.");
        }

        const recipe = {
            recipeId: id,
            recipeName: name,
            version,
            ingredients
        };

        const isEditing = editingRecipeId !== null;

        await apiRequest(
            isEditing
                ? `${API.recipes}/${encodeURIComponent(editingRecipeId)}`
                : API.recipes,
            {
                method: isEditing ? "PUT" : "POST",
                body: JSON.stringify(recipe)
            }
        );

        showMessage(
            "recipeMessage",
            isEditing
                ? "Recipe updated successfully."
                : "Recipe created successfully.",
            "success"
        );

        resetRecipeForm();
        await loadRecipes();

    } catch (error) {
        showMessage("recipeMessage", error.message, "error");
    }
}

/* Load and display recipes */

async function loadRecipes() {
    try {
        const data = await apiRequest(API.recipes);

        recipes = Array.isArray(data)
            ? data
            : Array.isArray(data?.content)
                ? data.content
                : [];

        renderRecipes();
        updateStatistics();

        showMessage(
            "listMessage",
            `${recipes.length} recipe(s) loaded.`,
            "success"
        );

    } catch (error) {
        $("recipesTableBody").innerHTML = `
            <tr>
                <td colspan="5">
                    Could not load recipes.
                    ${escapeHtml(error.message)}
                </td>
            </tr>
        `;

        showMessage("listMessage", error.message, "error");
    }
}

function renderRecipes() {
    const tbody = $("recipesTableBody");

    if (recipes.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5">
                    No recipes found. Create your first recipe above.
                </td>
            </tr>
        `;

        renderRecipeDropdown();
        return;
    }

    tbody.innerHTML = recipes.map(recipe => {
        const id = String(getRecipeId(recipe));
        const ingredients = getIngredients(recipe);

        return `
            <tr>
                <td>${escapeHtml(id)}</td>
                <td>${escapeHtml(getRecipeName(recipe))}</td>
                <td>${escapeHtml(recipe.version ?? 1)}</td>
                <td>${ingredients.length}</td>
                <td>
                    <button class="btn btn-secondary btn-small"
                        onclick="editRecipe('${escapeHtml(id)}')">
                        Edit
                    </button>

                    <button class="btn-remove"
                        onclick="deleteRecipe('${escapeHtml(id)}')">
                        Delete
                    </button>
                </td>
            </tr>
        `;
    }).join("");

    renderRecipeDropdown();
}

async function deleteRecipe(id) {
    if (!confirm(`Delete recipe ${id}?`)) return;

    try {
        await apiRequest(
            `${API.recipes}/${encodeURIComponent(id)}`,
            { method: "DELETE" }
        );

        showMessage("listMessage", "Recipe deleted.", "success");
        await loadRecipes();

    } catch (error) {
        showMessage("listMessage", error.message, "error");
    }
}

function renderRecipeDropdown() {
    const select = $("evalRecipeId");
    const previousValue = select.value;

    select.innerHTML = `
        <option value="">Choose a saved recipe</option>

        ${recipes.map(recipe => `
            <option value="${escapeHtml(getRecipeId(recipe))}">
                ${escapeHtml(getRecipeName(recipe))}
                (${escapeHtml(getRecipeId(recipe))})
            </option>
        `).join("")}
    `;

    if (recipes.some(
        recipe => String(getRecipeId(recipe)) === previousValue
    )) {
        select.value = previousValue;
    }
}

/* Load ingredient fields for batch evaluation */

function loadBatchIngredients() {
    const id = $("evalRecipeId").value;

    const recipe = recipes.find(
        item => String(getRecipeId(item)) === id
    );

    const area = $("batchIngredientsArea");

    $("evaluationResult").innerHTML = "";
    showMessage("evalMessage", "");

    if (!recipe) {
        area.innerHTML = `
            <p class="empty-state">
                Select a recipe to load its ingredients.
            </p>
        `;
        return;
    }

    const ingredients = getIngredients(recipe);

    if (!ingredients.length) {
        area.innerHTML = `
            <p class="empty-state">
                This recipe has no ingredients.
            </p>
        `;
        return;
    }

    area.innerHTML = ingredients.map((item, index) => `
        <div class="batch-row">
            <strong>
                ${escapeHtml(getIngredientName(item))}
                <small>
                    Target: ${escapeHtml(item.targetPercentage)}%
                </small>
            </strong>

            <label>
                Actual weight (g)
                <input class="actual-weight" type="number"
                    min="0.001" step="any"
                    data-index="${index}"
                    placeholder="Enter grams" required>
            </label>

            <div>
                <small>
                    Tolerance: ${escapeHtml(
                        item.tolerancePercentage ?? 0
                    )}%
                </small>
            </div>
        </div>
    `).join("");
}

/* Evaluate a batch - corrected request fields */

async function evaluateBatch(event) {
    event.preventDefault();

    try {
        const recipeId = $("evalRecipeId").value;

        const recipe = recipes.find(
            item => String(getRecipeId(item)) === recipeId
        );

        if (!recipe) {
            throw new Error("Please select a saved recipe.");
        }

        const recipeIngredients = getIngredients(recipe);

        if (recipeIngredients.length === 0) {
            throw new Error(
                "The selected recipe has no ingredients."
            );
        }

        const actualInputs = [
            ...document.querySelectorAll(
                "#batchIngredientsArea .actual-weight"
            )
        ];

        if (actualInputs.length !== recipeIngredients.length) {
            throw new Error(
                "Ingredient fields do not match the selected recipe. Please select the recipe again."
            );
        }

        const ingredients = recipeIngredients.map((item, index) => {
            const inputValue = actualInputs[index].value.trim();
            const actualWeight = Number(inputValue);

            const targetPercentage = Number(item.targetPercentage);
            const tolerancePercentage = Number(
                item.tolerancePercentage
            );

            if (
                inputValue === "" ||
                !Number.isFinite(actualWeight) ||
                actualWeight <= 0
            ) {
                throw new Error(
                    `Enter a valid positive weight for ${getIngredientName(item)}.`
                );
            }

            if (
                !Number.isFinite(targetPercentage) ||
                !Number.isFinite(tolerancePercentage)
            ) {
                throw new Error(
                    `Target percentage or tolerance is missing for ${getIngredientName(item)}. Check the saved recipe.`
                );
            }

            return {
                name: getIngredientName(item),
                targetPercentage: targetPercentage,
                tolerancePercentage: tolerancePercentage,
                actualWeight: actualWeight
            };
        });

        const batchId = "BATCH-" + Date.now();

        /*
         * BatchEvaluationRequest in BatchController.java
         * expects batchId and ingredients.
         *
         * Each ingredient must include:
         * name, targetPercentage, tolerancePercentage,
         * and actualWeight.
         */

        const requestBody = {
            batchId: batchId,
            ingredients: ingredients
        };

        showMessage(
            "evalMessage",
            "Evaluating batch...",
            "info"
        );

        const result = await apiRequest(API.evaluate, {
            method: "POST",
            body: JSON.stringify(requestBody)
        });

        const decision = String(
            result?.decision ?? result?.status ?? "COMPLETED"
        ).toUpperCase();

        batchHistory.unshift({
            decision: decision,
            result: result
        });

        updateStatistics();
        displayEvaluationResult(result, batchId);

        showMessage(
            "evalMessage",
            "Batch evaluation completed.",
            "success"
        );

    } catch (error) {
        showMessage(
            "evalMessage",
            error.message,
            "error"
        );
    }
}

/* Display evaluation result */

function displayEvaluationResult(result, batchId) {
    const decision = String(
        result?.decision ?? result?.status ?? "COMPLETED"
    ).toUpperCase();

    const approved = decision.includes("APPROV");
    const rejected = decision.includes("REJECT");

    const className = approved
        ? "result-approved"
        : rejected
            ? "result-rejected"
            : "";

    $("evaluationResult").innerHTML = `
        <div class="result-card ${className}">
            <h3>${escapeHtml(decision)}</h3>

            <p>
                <strong>Batch ID:</strong>
                ${escapeHtml(result?.batchId ?? batchId)}
            </p>

            <p>
                <strong>Recipe ID:</strong>
                ${escapeHtml($("evalRecipeId").value)}
            </p>

            <p>
                ${escapeHtml(
                    result?.message ??
                    result?.reason ??
                    "Evaluation response received from the backend."
                )}
            </p>
        </div>
    `;
}

/* Dashboard counters */

function updateStatistics() {
    $("recipeCount").textContent = recipes.length;
    $("batchCount").textContent = batchHistory.length;

    $("approvedCount").textContent = batchHistory.filter(item =>
        String(item.decision).includes("APPROV")
    ).length;

    $("rejectedCount").textContent = batchHistory.filter(item =>
        String(item.decision).includes("REJECT")
    ).length;
}

/* Start the application */

document.addEventListener("DOMContentLoaded", () => {
    $("addIngredientBtn").addEventListener(
        "click",
        () => addIngredientRow()
    );

    $("recipeForm").addEventListener("submit", saveRecipe);

    $("recipeForm").addEventListener("reset", () => {
        setTimeout(() => {
            editingRecipeId = null;
            $("recipeId").disabled = false;
            $("recipeVersion").value = 1;
            $("recipeIngredients").innerHTML = "";

            addIngredientRow();
            updateTargetTotal();
        }, 0);
    });

    $("recipeIngredients").addEventListener(
        "input",
        updateTargetTotal
    );

    $("refreshRecipes").addEventListener(
        "click",
        loadRecipes
    );

    $("evalRecipeId").addEventListener(
        "change",
        loadBatchIngredients
    );

    $("evalForm").addEventListener(
        "submit",
        evaluateBatch
    );

    updateTargetTotal();
    updateStatistics();
    loadRecipes();
});
